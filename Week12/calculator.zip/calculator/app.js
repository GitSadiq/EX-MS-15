var res = document.getElementById("res");
function main(dat){
    if (dat == "erase"){
        res.innerText = ""
    }
    else if (dat == "enter"){
        res.innerText = eval(res.innerText);
    }
    else{
        res.innerText = res.innerText + dat;
        console.log(res)
    }
} 


// var res = document.getElementById("res")

// function main(val){
//     if (val === "erase"){
//         res.innerText = ""
//     }
//     else if (val === "enter"){
//         res.innerText = res.innerText
//     }
//     else{
//            res.innerText = res.innerText + val
//            console.log(res)
          
//     }
    
// }